CREATE DATABASE IVF_EQUIPMENTS;

USE IVF_EQUIPMENTS;

-- FIRST BUSINESS MOMENTS DECISION---------------------------------------------------------------------------------

## 1) MEAN : ------------------------------------------
SELECT 
    AVG(max_capacity_hrs) AS MEAN_VALUE
    FROM ivf_equipment_utilization_2yrs;
SELECT 
    AVG(utilization_hrs) AS MEAN_VALUE
    FROM ivf_equipment_utilization_2yrs;
SELECT 
    AVG(utilization_pct) AS MEAN_VALUE
    FROM ivf_equipment_utilization_2yrs;
SELECT 
    AVG(idle_hrs) AS MEAN_VALUE
    FROM ivf_equipment_utilization_2yrs;
SELECT 
    AVG(technical_downtime_hrs) AS MEAN_VALUE
    FROM ivf_equipment_utilization_2yrs;
SELECT 
    AVG(planned_maintenance_hrs) AS MEAN_VALUE
    FROM ivf_equipment_utilization_2yrs;
SELECT 
    AVG(workflow_delay_events) AS MEAN_VALUE
    FROM ivf_equipment_utilization_2yrs;
SELECT 
    AVG(average_delay_minutes) AS MEAN_VALUE
    FROM ivf_equipment_utilization_2yrs;
SELECT 
    AVG(total_cases_day_lab) AS MEAN_VALUE
    FROM ivf_equipment_utilization_2yrs;
 
 ## 2) MEDIUM : ------------------------------------
 
 SELECT AVG(max_capacity_hrs) AS MEDIAN_VALUE
FROM (
    SELECT max_capacity_hrs,
           ROW_NUMBER() OVER (ORDER BY max_capacity_hrs) AS MCH,
           COUNT(*) OVER () AS total_rows
    FROM ivf_equipment_utilization_2yrs
) t
WHERE MCH IN (FLOOR((total_rows + 1) / 2),
             CEIL((total_rows + 1) / 2));

SELECT AVG(utilization_hrs) AS MEDIAN_VALUE
FROM (
    SELECT utilization_hrs,
           ROW_NUMBER() OVER (ORDER BY utilization_hrs) AS UH,
           COUNT(*) OVER () AS total_rows
    FROM ivf_equipment_utilization_2yrs
) t
WHERE UH IN (FLOOR((total_rows + 1) / 2),
             CEIL((total_rows + 1) / 2));

SELECT AVG(utilization_pct) AS MEDIAN_VALUE
FROM (
    SELECT utilization_pct,
           ROW_NUMBER() OVER (ORDER BY utilization_pct) AS UP,
           COUNT(*) OVER () AS total_rows
    FROM ivf_equipment_utilization_2yrs
) t
WHERE UP IN (FLOOR((total_rows + 1) / 2),
             CEIL((total_rows + 1) / 2));

SELECT AVG(idle_hrs) AS MEDIAN_VALUE
FROM (
    SELECT idle_hrs,
           ROW_NUMBER() OVER (ORDER BY idle_hrs) AS ID,
           COUNT(*) OVER () AS total_rows
    FROM ivf_equipment_utilization_2yrs
) t
WHERE ID IN (FLOOR((total_rows + 1) / 2),
             CEIL((total_rows + 1) / 2));

SELECT AVG(technical_downtime_hrs) AS MEDIAN_VALUE
FROM (
    SELECT technical_downtime_hrs,
           ROW_NUMBER() OVER (ORDER BY technical_downtime_hrs) AS TDH,
           COUNT(*) OVER () AS total_rows
    FROM ivf_equipment_utilization_2yrs
) t
WHERE TDH IN (FLOOR((total_rows + 1) / 2),
             CEIL((total_rows + 1) / 2));

SELECT AVG(planned_maintenance_hrs) AS MEDIAN_VALUE
FROM (
    SELECT planned_maintenance_hrs,
           ROW_NUMBER() OVER (ORDER BY planned_maintenance_hrs) AS PMH,
           COUNT(*) OVER () AS total_rows
    FROM ivf_equipment_utilization_2yrs
) t
WHERE PMH IN (FLOOR((total_rows + 1) / 2),
             CEIL((total_rows + 1) / 2));

SELECT AVG(workflow_delay_events) AS MEDIAN_VALUE
FROM (
    SELECT workflow_delay_events,
           ROW_NUMBER() OVER (ORDER BY workflow_delay_events) AS WFE,
           COUNT(*) OVER () AS total_rows
    FROM ivf_equipment_utilization_2yrs
) t
WHERE WFE IN (FLOOR((total_rows + 1) / 2),
             CEIL((total_rows + 1) / 2));

SELECT AVG(avg_delay_minutes) AS MEDIAN_VALUE
FROM (
    SELECT avg_delay_minutes,
           ROW_NUMBER() OVER (ORDER BY avg_delay_minutes) AS ADM,
           COUNT(*) OVER () AS total_rows
    FROM ivf_equipment_utilization_2yrs
) t
WHERE ADM IN (FLOOR((total_rows + 1) / 2),
             CEIL((total_rows + 1) / 2));

SELECT AVG(total_cases_day_lab) AS MEDIAN_VALUE
FROM (
    SELECT total_cases_day_lab,
           ROW_NUMBER() OVER (ORDER BY total_cases_day_lab) AS TCD,
           COUNT(*) OVER () AS total_rows
    FROM ivf_equipment_utilization_2yrs
) t
WHERE TCD IN (FLOOR((total_rows + 1) / 2),
             CEIL((total_rows + 1) / 2));


## 3) MODE : ---------------------------------------------

 SELECT max_capacity_hrs AS MODE_VALUE
FROM ivf_equipment_utilization_2yrs 
GROUP BY max_capacity_hrs
ORDER BY COUNT(*) DESC
LIMIT 1;

SELECT utilization_hrs AS MODE_VALUE
FROM ivf_equipment_utilization_2yrs 
GROUP BY utilization_hrs
ORDER BY COUNT(*) DESC
LIMIT 1;

SELECT utilization_pct AS MODE_VALUE
FROM ivf_equipment_utilization_2yrs 
GROUP BY utilization_pct
ORDER BY COUNT(*) DESC
LIMIT 1;

SELECT idle_hrs AS MODE_VALUE
FROM ivf_equipment_utilization_2yrs 
GROUP BY idle_hrs
ORDER BY COUNT(*) DESC
LIMIT 1;

SELECT technical_downtime_hrs AS MODE_VALUE
FROM ivf_equipment_utilization_2yrs 
GROUP BY technical_downtime_hrs
ORDER BY COUNT(*) DESC
LIMIT 1;

SELECT planned_maintenance_hrs AS MODE_VALUE
FROM ivf_equipment_utilization_2yrs 
GROUP BY planned_maintenance_hrs
ORDER BY COUNT(*) DESC
LIMIT 1;

SELECT workflow_delay_events AS MODE_VALUE
FROM ivf_equipment_utilization_2yrs 
GROUP BY workflow_delay_events
ORDER BY COUNT(*) DESC
LIMIT 1;

SELECT avg_delay_minutes AS MODE_VALUE
FROM ivf_equipment_utilization_2yrs 
GROUP BY avg_delay_minutes
ORDER BY COUNT(*) DESC
LIMIT 1;

SELECT total_cases_day_lab AS MODE_VALUE
FROM ivf_equipment_utilization_2yrs 
GROUP BY total_cases_day_lab
ORDER BY COUNT(*) DESC
LIMIT 1;
 
 -- SECOND BUSINESS MOMENTS DECISIONS :----------------------------------------------------------------------------
 ## 1) VARAIANCE : --------------------------------------
 
 SELECT 
    VARIANCE(max_capacity_hrs) AS VARIANCE_VALUE
FROM
    ivf_equipment_utilization_2yrs;

 SELECT
    VARIANCE(utilization_hrs) AS VARIANCE_VALUE
FROM ivf_equipment_utilization_2yrs;

 SELECT
    VARIANCE(utilization_pct) AS VARIANCE_VALUE
FROM ivf_equipment_utilization_2yrs;

 SELECT
    VARIANCE(idle_hrs) AS VARIANCE_VALUE
FROM ivf_equipment_utilization_2yrs;

 SELECT
    VARIANCE(technical_downtime_hrs) AS VARIANCE_VALUE
FROM ivf_equipment_utilization_2yrs;

 SELECT
    VARIANCE(planned_maintenance_hrs) AS VARIANCE_VALUE
FROM ivf_equipment_utilization_2yrs;

 SELECT
    VARIANCE(workflow_delay_events) AS VARIANCE_VALUE
FROM ivf_equipment_utilization_2yrs;

 SELECT
    VARIANCE(avg_delay_minutes) AS VARIANCE_VALUE
FROM ivf_equipment_utilization_2yrs;

 SELECT
    VARIANCE(total_cases_day_lab) AS VARIANCE_VALUE
FROM ivf_equipment_utilization_2yrs;

## 2) STANDARD DEVIATION : --------------------------------
SELECT    
    STDDEV(max_capacity_hrs) AS STD_DEVIATION_VALUE
FROM ivf_equipment_utilization_2yrs;

SELECT    
    STDDEV(utilization_hrs) AS STD_DEVIATION_VALUE
FROM ivf_equipment_utilization_2yrs;

SELECT    
    STDDEV(utilization_pct) AS STD_DEVIATION_VALUE
FROM ivf_equipment_utilization_2yrs;

SELECT    
    STDDEV(idle_hrs) AS STD_DEVIATION_VALUE
FROM ivf_equipment_utilization_2yrs;

SELECT    
    STDDEV(technical_downtime_hrs) AS STD_DEVIATION_VALUE
FROM ivf_equipment_utilization_2yrs;

SELECT    
    STDDEV(planned_maintenance_hrs) AS STD_DEVIATION_VALUE
FROM ivf_equipment_utilization_2yrs;

SELECT    
    STDDEV(workflow_delay_events) AS STD_DEVIATION_VALUE
FROM ivf_equipment_utilization_2yrs;

SELECT    
    STDDEV(avg_delay_minutes) AS STD_DEVIATION_VALUE
FROM ivf_equipment_utilization_2yrs;

SELECT    
    STDDEV(total_cases_day_lab) AS STD_DEVIATION_VALUE
FROM ivf_equipment_utilization_2yrs;

## 3) RANGE :-----------------------------------
  
SELECT
    MAX(max_capacity_hrs) - MIN(max_capacity_hrs) AS RANGE_VALUE
FROM ivf_equipment_utilization_2yrs;

SELECT
    MAX(utilization_hrs) - MIN(utilization_hrs) AS RANGE_VALUE
FROM ivf_equipment_utilization_2yrs;

SELECT
    MAX(utilization_pct) - MIN(utilization_pct) AS RANGE_VALUE
FROM ivf_equipment_utilization_2yrs;

SELECT
    MAX(idle_hrs) - MIN(idle_hrs) AS RANGE_VALUE
FROM ivf_equipment_utilization_2yrs;

SELECT
    MAX(technical_downtime_hrs) - MIN(technical_downtime_hrs) AS RANGE_VALUE
FROM ivf_equipment_utilization_2yrs;

SELECT
    MAX(planned_maintenance_hrs) - MIN(planned_maintenance_hrs) AS RANGE_VALUE
FROM ivf_equipment_utilization_2yrs;

SELECT
    MAX(workflow_delay_events) - MIN(workflow_delay_events) AS RANGE_VALUE
FROM ivf_equipment_utilization_2yrs;

SELECT
    MAX(avg_delay_minutes) - MIN(avg_delay_minutes) AS RANGE_VALUE
FROM ivf_equipment_utilization_2yrs;

SELECT
    MAX(total_cases_day_lab) - MIN(total_cases_day_lab) AS RANGE_VALUE
FROM ivf_equipment_utilization_2yrs;

-- THIRD BUSINESS MOMENT DECISIONS : --------------------------------------------------------------------------------

## 1) SKEWNESS :-------------------------

SELECT
    AVG(POWER(utilization_hrs - stats.mean_util, 3)) /
    POWER(MAX(stats.stddev_util), 3) AS skewness
FROM ivf_equipment_utilization_2yrs
CROSS JOIN (
    SELECT
        AVG(utilization_hrs) AS mean_util,
        STDDEV_POP(utilization_hrs) AS stddev_util
    FROM ivf_equipment_utilization_2yrs
) stats;

-- FOURTH BUSINESS MOMENT DECISIONS : ---------------------------------------------------------------------------------

## 1) KURTOSIS :-----------------------
     
SELECT
    AVG(POWER(utilization_hrs - stats.mean_util, 4)) /
    POWER(MAX(stats.stddev_util), 4) AS kurtosis
FROM ivf_equipment_utilization_2yrs
CROSS JOIN (
    SELECT
        AVG(utilization_hrs) AS mean_util,
        STDDEV_POP(utilization_hrs) AS stddev_util
    FROM ivf_equipment_utilization_2yrs
) stats;

