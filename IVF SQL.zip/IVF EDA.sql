/********************** DATA PREPROCESSING ************************************/
-------- TYPECASTING -------

SELECT COUNT(*) AS empty_dates
FROM ivf_equipment_utilization_2yrs
WHERE date = '';

UPDATE ivf_equipment_utilization_2yrs
SET date = NULL
WHERE date = '';

UPDATE ivf_equipment_utilization_2yrs
SET date = STR_TO_DATE(date, '%d-%m-%Y')
WHERE date IS NOT NULL
  AND date <> '';

SELECT DISTINCT date
FROM  ivf_equipment_utilization_2yrs
LIMIT 10;

ALTER TABLE ivf_equipment_utilization_2yrs
MODIFY date DATE;

SELECT date 
FROM ivf_equipment_utilization_2yrs;

/* BOOLEAN*/
SELECT redundancy_available
FROM ivf_equipment_utilization_2yrs;
UPDATE ivf_equipment_utilization_2yrs
SET redundancy_available =
CASE
    WHEN UPPER( redundancy_available) IN ('TRUE', 'YES', 'Y', '1') THEN 1
    ELSE 0
END;

ALTER TABLE ivf_equipment_utilization_2yrs
MODIFY date DATE,
MODIFY lab_id VARCHAR(50),
MODIFY equipment_id VARCHAR(50),
MODIFY equipment_type VARCHAR(50),
MODIFY max_capacity_hrs INT,
MODIFY utilization_hrs DECIMAL(10,2),
MODIFY utilization_pct DECIMAL(5,2),
MODIFY idle_hrs DECIMAL(10,2),
MODIFY technical_downtime_hrs INT,
MODIFY planned_maintenance_hrs DECIMAL(10,2),
MODIFY workflow_delay_events INT,
MODIFY avg_delay_minutes DECIMAL(10,2),
MODIFY primary_procedure VARCHAR(50),
MODIFY redundancy_available BOOLEAN,
MODIFY total_cases_day_lab INT;

DESCRIBE ivf_equipment_utilization_2yrs;

----- OUTLIERS --------

WITH ordered_data AS(
	SELECT total_cases_day_lab,
		ROW_NUMBER() OVER (ORDER BY total_cases_day_lab) AS rn,
		COUNT(*) OVER() AS total_rows
	FROM ivf_equipment_utilization_2yrs
)

SELECT
	MAX(CASE WHEN rn = FLOOR(0.25 * (total_rows+1))THEN total_cases_day_lab END) AS Q1,
    MAX(CASE WHEN rn = FLOOR(0.75 * (total_rows+1))THEN total_cases_day_lab END) AS Q3
FROM  ordered_data;

SELECT * 
FROM ivf_equipment_utilization_2yrs,STATS
WHERE total_cases_day_lab < (Q1 - 1.5*(Q3-Q1))
or	  total_cases_day_lab > (Q1 + 1.5*(Q3-Q1));

----- ZEO AND NEAR ZERO VARIANCE -----

SELECT 
	MIN(redundancy_available) AS MIN_VAL,
    MAX(redundancy_available) AS MAX_VAL
FROM ivf_equipment_utilization_2yrs;

SELECT
	COUNT(DISTINCT redundancy_available) AS DISTINCT_VAL
FROM  ivf_equipment_utilization_2yrs;

SELECT
    STDDEV_POP(redundancy_available) AS std_dev
FROM ivf_equipment_utilization;

SELECT
	COUNT(DISTINCT redundancy_available) AS DISTINCT_VAL
FROM  ivf_equipment_utilization_2yrs;

-------- DISCRETIZATION ------------
-- TOTAL_CASES_DAY_LAB--
SELECT
	total_cases_day_lab,
    CASE
		WHEN total_cases_day_lab BETWEEN 0 AND 10 THEN 'LOW'
		WHEN total_cases_day_lab BETWEEN 10 AND 20 THEN 'MEDIUM'
		ELSE 'HIGH'
	END AS total_case_category
FROM ivf_equipment_utilization_2yrs;

-- UTILIZATION_PCT--
SELECT
	 utilization_pct,
     CASE
		WHEN  utilization_pct < 50 THEN 'UNDERUTILIZED'
        WHEN  utilization_pct BETWEEN 50 AND 80 THEN 'OPTIMAL'
        ELSE 'OVERUTILIZED'
	END  AS  utilization_pct_cat
FROM ivf_equipment_utilization_2yrs;

-- DOWNTIME HOURS--
SELECT
	technical_downtime_hrs,
    CASE
		WHEN technical_downtime_hrs = 0 THEN 'NO DOWNTIME'
        WHEN technical_downtime_hrs BETWEEN 1 AND 3 THEN 'LOW'
        ELSE 'HIGH'
	END AS technical_downtime_hrs_cat
FROM ivf_equipment_utilization_2yrs;

------- -- FEATURE SCALING ---------
-- UTILIZATION_PCT ----
SELECT 
	utilization_pct,
    (utilization_pct - stats.min_val)/
    (stats.max_val - stats.min_val) AS Scaled_utilization_pct
FROM ivf_equipment_utilization_2yrs
CROSS JOIN(
	SELECT
    MIN(utilization_pct) AS min_val,
    MAX(utilization_pct) AS max_val
    FROM ivf_equipment_utilization_2yrs
) stats;
    
-- UTILIZATION_HRS -- 
SELECT 
	utilization_hrs,
    (utilization_hrs - stats.min_val)/
    (stats.max_val - stats.min_val) AS Scaled_utilization_hrs
FROM ivf_equipment_utilization
CROSS JOIN(
	SELECT
    MIN(utilization_hrs) AS min_val,
    MAX(utilization_hrs) AS max_val
    FROM ivf_equipment_utilization
) stats;

 -- IDLE_HRS -- 
 SELECT 
	idle_hrs,
    (idle_hrs- stats.min_val)/
    (stats.max_val - stats.min_val) AS Scaled_idle_hrs
FROM ivf_equipment_utilization
CROSS JOIN(
	SELECT
    MIN(idle_hrs) AS min_val,
    MAX(idle_hrs) AS max_val
    FROM ivf_equipment_utilization
) stats;

-- AVG_DELAY_MINUTES--
SELECT 
	 avg_delay_minutes,
    (avg_delay_minutes- stats.min_val)/
    (stats.max_val - stats.min_val) AS Scaled_idle_hrs
FROM ivf_equipment_utilization
CROSS JOIN(
	SELECT
    MIN(avg_delay_minutes) AS min_val,
    MAX(avg_delay_minutes) AS max_val
    FROM ivf_equipment_utilization
) stats;
