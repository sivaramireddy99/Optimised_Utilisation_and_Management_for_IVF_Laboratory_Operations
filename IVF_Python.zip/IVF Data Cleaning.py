#################  DATA CLEANING/ DATA PREPROCESSING    #######################

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv(r"C:\Users\badam\Downloads\ivf_equipment_utilization_2yrs.csv")

df.describe()

df.info()
df.shape

### 1. TYPECASTING/ TYPE CONVERSION...............................
df.dtypes

help(df.astype)

# Example: CONVERT TO dATETIME...............

df['date'] = pd.to_datetime(df['date'], errors='coerce')
df = df.dropna(subset=['date'])
df['month'] = df['date'].dt.month
df['day_of_week'] = df['date'].dt.dayofweek

#### FOUND THE SERIES OF DATE LIKE 1 ,2 ,3 ,4-----N
series_date = pd.Series(pd.date_range('20200101', periods=6))
series_date

### 2. HANDLING DUPLICATES.......................................

help(df.duplicated)

## FIND DUPLICATES........
# IF FALSE = NO DUPLICTE DATA ,   TRUE = DUPLICATE DATA

duplicate = df.duplicated()
df.duplicated().sum()
duplicate

## SHOWS THE DUPLICATES..............
df[df.duplicated()]

###  COUNTS THE TOTAL OF DUPLICATES.
sum(duplicate)

duplicate = df.duplicated(keep = 'last')
duplicate

df = df.drop_duplicates()

### 3. OUTLIERS..................................
import pandas as pd
import numpy as np
import seaborn as sns

df.dtypes

#####USING IQR   .................. 
numeric_cols = df.select_dtypes(include='number').columns

for col in numeric_cols:
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    
    outliers = df[(df[col] < lower) | (df[col] > upper)]
    print({len(outliers)})
    
###USING WINSORIZATION..................
numerical_cols = df.select_dtypes(include=['int64', 'float64']).columns

for col in numerical_cols:
    if col not in ['month', 'day_of_week', 'is_weekend']:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1
        lower = Q1 - 1.5 * IQR
        upper = Q3 + 1.5 * IQR
        df[col] = np.where(df[col] < lower, lower, np.where(df[col] > upper, upper, df[col]))


### 4.ZERO AND NON-ZERO VARIANCE..................
for col in numerical_cols:
    if df[col].var() == 0:
        print(f"Column {col} has zero variance and may be dropped.")

#### 5. HANDLING MISSING VALUES......................
df['date'] = pd.to_datetime(df['date'], dayfirst=True, errors='coerce')
df = df.dropna(subset=['date'])

df['month'] = df['date'].dt.month
df['day_of_week'] = df['date'].dt.dayofweek
df['is_weekend'] = df['day_of_week'].isin([5, 6]).astype(int)

numerical_cols = df.select_dtypes(include=[np.number]).columns.tolist()
for col in numerical_cols:
    df[col] = df[col].fillna(df[col].median())

categorical_cols = ['lab_id', 'equipment_type', 'primary_procedure', 'redundancy_available']
for col in categorical_cols:
    df[col] = df[col].fillna(df[col].mode()[0])


### 6. DISCRETIZATION..................................

df['utilization_pct_levels'] = pd.cut(
    df['utilization_pct'],
    bins = 3,
    labels = ['Low', 'Medium', 'High'])


df['utilization_hrs_levels'] = pd.cut(
    df['utilization_hrs'],
    bins = 3,
    labels=['Low Usage', 'Medium Usage', 'High Usage'])

df['idle_hrs_levels'] = pd.cut(
    df['idle_hrs'],
    bins = 3,
    labels=['No idle', 'Moderate idle', 'High idle'])

df['technical_downtime_hrs_levels'] = pd.cut(
    df['technical_downtime_hrs'],
    bins = 3,
    labels=['No Downtime', 'Minor Downtime', 'Major Downtime'])

df['avg_delay_minutes_levels'] = pd.cut(
    df['avg_delay_minutes'],
    bins = 3,
    labels=['Short Delay', 'Medium Delay', 'Long Delay'])


## 7.DUMMY VARIABLES..............................

df = pd.get_dummies(df, columns=['lab_id', 
                                 'equipment_type',
                                 'primary_procedure'], 
                    drop_first=True)
                    
### 8. TRANSFORMATION.................................

from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()

transformation_cols = ['utilization_hrs','idle_hrs','technical_downtime_hrs',
'planned_maintenance_hrs','avg_delay_minutes','workflow_delay_events','total_cases_day_lab']

df[transformation_cols] = scaler.fit_transform(df[transformation_cols])

### 9. FEATURE SCALING.........................

from sklearn.preprocessing import StandardScaler

cat_cols = df.select_dtypes(include=['object', 'category', 'bool']).columns

df_encoded = pd.get_dummies(df, columns=cat_cols, drop_first=True)

cols_to_scale = df_encoded.select_dtypes(include=['int64', 'float64']).columns

cols_to_scale = [c for c in cols_to_scale if c not in ['month', 'day_of_week', 'is_weekend']]

df_encoded[cols_to_scale].describe().round(2)


cols_to_scale = ['max_capacity_hrs', 'utilization_hrs', 'utilization_pct', 'idle_hrs', 
                 'technical_downtime_hrs', 'planned_maintenance_hrs', 'workflow_delay_events', 
                 'avg_delay_minutes', 'total_cases_day_lab']

scaler = StandardScaler()
df_encoded[cols_to_scale] = scaler.fit_transform(df_encoded[cols_to_scale])

### 10 STRING MANIPULATION..............................

df.columns = df.columns.str.strip().str.lower().str.replace(" ", "_")

print(df.columns.tolist())
string_cols = df.select_dtypes(include='object').columns
for col in string_cols:
    df[col] = df[col].astype(str).str.strip().str.lower()


#### DOWNLOAD THE CLEANED DATASET..........................
df.to_csv(
    r"C:\Users\badam\Downloads\cleaned_ivf_dataset.csv",
    index=False
)



####################  DATA UNDERSTANDING -##################################--------------------------
#----- CLEANED DATA SET --------------

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv(r"C:\Users\badam\Downloads\cleaned_ivf_dataset.csv")

df.shape    

df.dtypes   

df.head()  

df.tail()   

df.head(15)   
df.tail(15)

df.describe()   
df.describe(include = 'object') 

df.info()  ### SHOWS FULL INFORMATION ABOUT DATAFRAME.

df.columns

'''IVF_Cleaned_dataset = ['date', 'equipment_id', 'max_capacity_hrs', 'utilization_hrs',
       'utilization_pct', 'idle_hrs', 'technical_downtime_hrs',
       'planned_maintenance_hrs', 'workflow_delay_events', 'avg_delay_minutes',
       'redundancy_available', 'total_cases_day_lab', 'month', 'day_of_week',
       'is_weekend', 'utilization_pct_levels', 'utilization_hrs_levels',
       'idle_hrs_levels', 'technical_downtime_hrs_levels',
       'avg_delay_minutes_levels', 'lab_id_lab_chn_02',
       'equipment_type_incubator', 'equipment_type_microscope',
       'equipment_type_incubator.1', 'primary_procedure_fertilization_check',
       'primary_procedure_icsi', 'primary_procedure_ivf']'''

IVF_CLeaned_dataset = ['max_capacity_hrs',
           'utilization_hrs', 'utilization_pct', 'idle_hrs',
           'technical_downtime_hrs', 'planned_maintenance_hrs',
           'workflow_delay_events', 'avg_delay_minutes','total_cases_day_lab']

IVF_Cleaned_dataset = df.iloc[:,:-1].select_dtypes(include = "number")

###### 1.  FIRST MOMENT OF BUSINESS DECISION:---MEAN , MEDIAN, MODE
###### 2.  SECOND MOMENT OF BUSINESS DECISION:--- VARIANCE, STANDARD DEVIATION, RANGE
###### 3.  THIRD MOMENT OF BUSINESS DECISION :---- SKEWENESS
###### 4. FOURTH MOMENT OF BUSINESS DECISION :---- KURTOSIS

for col in IVF_Cleaned_dataset:
    print(f"\nStatistics for {col}:")
    print(f"Mean : {df[col].mean()}")
    print(f"Median : {df[col].median()}")
    print(f"Mode : {df[col].mode()[0]}")
    print(f"Variance : {df[col].var()}")
    print(f"Standard Deviation : {df[col].std()}")
    print(f"Range : {df[col].max() - df[col].min()}")
    print(f"Skewness : {df[col].skew()}")
    print(f"Kurtosis : {df[col].kurt()}")

########## GRAPHICAL REPRSENTATION ## : ------------------------------
#######    UNIVARIATE PLOTS  :------------------------------..........
### 1.. HISTOGRAM PLOT.............

import matplotlib.pyplot as plt

for col in IVF_Cleaned_dataset:
    plt.figure
    plt.hist(df[col])
    plt.title(f'Histogram of {col}')
    plt.xlabel(col)
    plt.ylabel('Frequency')
    plt.show()
    
#####  DENSITY PLOT...............
import seaborn as sns

for col in IVF_Cleaned_dataset:
    sns.distplot(df[col])
    sns.kdeplot(df[col])
    plt.xlabel(col)
    plt.ylabel('Density')
    plt.show()
    
##### BOX PLOT....................
import matplotlib.pyplot as plt

for col in IVF_Cleaned_dataset:
    plt.figure
    plt.boxplot(df[col])
    plt.title(f'box plot of {col}')
    plt.xlabel(col)
    plt.ylabel('Frequency')
    plt.show()
    
#####   Q-Q PLOT..................
import scipy.stats as stats

for col in df.select_dtypes(include=['float64','int64']).columns:
    plt.figure(figsize=(5,5))
    stats.probplot(df[col].dropna(), dist="norm", plot=plt)
    plt.title(f"Q-Q Plot: {col}")
    plt.show()
    
#### 2..BIVARIATE PLOTS ................................................
#####  SCATTER PLOT.................

colors = ['blue', 'red', 'green', 'orange', 'purple', 'brown', 
          'pink', 'cyan', 'magenta', 'yellow', 'grey', 'olive', 'teal', 'lime']

IVF_CLeaned_dataset = ['max_capacity_hrs',
           'utilization_hrs', 'utilization_pct', 'idle_hrs',
           'technical_downtime_hrs', 'planned_maintenance_hrs',
           'workflow_delay_events', 'avg_delay_minutes','total_cases_day_lab']

plt.scatter(x = df['max_capacity_hrs'], y = df['utilization_hrs'], color = 'blue')

plt.scatter(x = df['utilization_hrs'], y = df['utilization_pct'],color = 'red')

plt.scatter(x = df['utilization_pct'], y = df['idle_hrs'],color = 'green')

plt.scatter(x = df['idle_hrs'], y = df['technical_downtime_hrs'],color = 'orange')

plt.scatter(x = df['technical_downtime_hrs'], y = df['planned_maintenance_hrs'],color = 'purple')

plt.scatter(x = df['planned_maintenance_hrs'], y = df['workflow_delay_events'],color = 'brown')

plt.scatter(x = df['workflow_delay_events'], y = df['avg_delay_minutes'],color = 'pink')

plt.scatter(x = df['avg_delay_minutes'], y = df['total_cases_day_lab'],color = 'cyan')

plt.scatter(x = df['total_cases_day_lab'], y = df['utilization_hrs'],color = 'magenta')


sns.boxplot(x = df["utilization_hrs"], y = df["total_cases_day_lab"])
plt.title("utilization_hrs vs total_cases_day_lab")
plt.show()

sns.violinplot(x = df["utilization_hrs"], y = df["total_cases_day_lab"])
plt.title("utilization_hrs vs total_cases_day_lab")
plt.show()

#### HEAT MAP....................
import seaborn as sns

subset = df[["utilization_hrs", "total_cases_day_lab"]]
sns.heatmap(subset.corr(), annot=True, cmap="coolwarm")

subset = df[["utilization_hrs", "idle_hrs"]]
sns.heatmap(subset.corr(), annot=True, cmap="coolwarm")
    
plt.figure(figsize=(10,8))
sns.heatmap(df.corr(numeric_only=True), annot=True, cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.show()

###### 3. MULTI VARIATE PLOTS..........................................
#####  PAIR PLOTS...............
numeric_cols = df.select_dtypes(include='number').columns

# Pairplot for multivariate analysis
sns.set(style="ticks", palette="Set2")  # Nice style and color palette
pairplot = sns.pairplot(
    df[numeric_cols],
    diag_kind='kde',      # Kernel density estimate on diagonal
    kind='scatter',       # Scatter plots for off-diagonal
    corner=False,         # Show full matrix (not just lower triangle)
    plot_kws={'alpha':0.6, 's':40}  # Transparency and point size
)
pairplot.fig.suptitle("Pairwise Relationships (Multivariate Analysis)", y=1.02)
plt.show()

#### FOR EVERY COLUMN FOR PAIR PLOTS:-

for i, col in enumerate(numeric_cols):
    
    sns.pairplot(df, y_vars=[col], x_vars=numeric_cols.drop(col), height=4, aspect=1, plot_kws={'color': colors[i%len(colors)]})
    plt.suptitle(f'Pair Plot for {col}', y=1.02)
    plt.show()