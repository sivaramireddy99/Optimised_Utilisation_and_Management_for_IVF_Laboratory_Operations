########################IVF EQUIPMENTS PROJECT #################################
##### DATA UNDERSTANDING ###############
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv(r"C:\Users\badam\Downloads\ivf_equipment_utilization_2yrs.csv")

df.shape    

df.dtypes   

df.head()  

df.tail()   

df.head(15)   
df.tail(15)

df.describe()   
df.describe(include = 'object') 

df.info()  ### SHOWS FULL INFORMATION ABOUT DATAFRAME.

df.columns

IVF_Equipments = ['date', 'lab_id', 'equipment_id', 'equipment_type', 'max_capacity_hrs',
       'utilization_hrs', 'utilization_pct', 'idle_hrs',
       'technical_downtime_hrs', 'planned_maintenance_hrs',
       'workflow_delay_events', 'avg_delay_minutes', 'primary_procedure',
       'redundancy_available', 'total_cases_day_lab']

IVF_Equipments = df.iloc[:,:-1].select_dtypes(include = "number")

###### 1.  FIRST MOMENT OF BUSINESS DECISION:---MEAN , MEDIAN, MODE
###### 2.  SECOND MOMENT OF BUSINESS DECISION:--- VARIANCE, STANDARD DEVIATION, RANGE
###### 3.  THIRD MOMENT OF BUSINESS DECISION :---- SKEWENESS
###### 4. FOURTH MOMENT OF BUSINESS DECISION :---- KURTOSIS

for col in IVF_Equipments:
    print(f"\nStatistics for {col}:")
    print(f"Mean : {df[col].mean()}")
    print(f"Median : {df[col].median()}")
    print(f"Mode : {df[col].mode()[0]}")
    print(f"Variance : {df[col].var()}")
    print(f"Standard Deviation : {df[col].std()}")
    print(f"Range : {df[col].max() - df[col].min()}")
    print(f"Skewness : {df[col].skew()}")
    print(f"Kurtosis : {df[col].kurt()}")


########## GRAPHICAL REPRSENTATION ## : ------------------------------
#######    UNIVARIATE PLOTS  :------------------------------..........
### 1.. HISTOGRAM PLOT.............

import matplotlib.pyplot as plt

for col in IVF_Equipments:
    plt.figure
    plt.hist(df[col])
    plt.title(f'Histogram of {col}')
    plt.xlabel(col)
    plt.ylabel('Frequency')
    plt.show()
    
#####  DENSITY PLOT...............
import seaborn as sns

for col in IVF_Equipments:
    sns.distplot(df[col])
    sns.kdeplot(df[col])
    plt.xlabel(col)
    plt.ylabel('Density')
    plt.show()
    
##### BOX PLOT....................
import matplotlib.pyplot as plt

for col in IVF_Equipments:
    plt.figure
    plt.boxplot(df[col])
    plt.title(f'box plot of {col}')
    plt.xlabel(col)
    plt.ylabel('Frequency')
    plt.show()

#####   Q-Q PLOT..................
import scipy.stats as stats

for col in df.select_dtypes(include=['float64','int64']).columns:
    plt.figure(figsize=(5,5))
    stats.probplot(df[col].dropna(), dist="norm", plot=plt)
    plt.title(f"Q-Q Plot: {col}")
    plt.show()

#### 2..BIVARIATE PLOTS ................................................
#####  SCATTER PLOT.................
  
colors = ['blue', 'red', 'green', 'orange', 'purple', 'brown', 
          'pink', 'cyan', 'magenta', 'yellow', 'grey', 'olive', 'teal', 'lime']

plt.scatter(x = df['utilization_hrs'], y = df['total_cases_day_lab'], color = 'blue')

plt.scatter(x = df['utilization_hrs'], y = df['idle_hrs'],color = 'red')

sns.boxplot(x = df["utilization_hrs"], y = df["total_cases_day_lab"])
plt.title("utilization_hrs vs total_cases_day_lab")
plt.show()

sns.violinplot(x = df["utilization_hrs"], y = df["total_cases_day_lab"])
plt.title("utilization_hrs vs total_cases_day_lab")
plt.show()

#### HEAT MAP....................
import seaborn as sns

subset = df[["utilization_hrs", "total_cases_day_lab"]]
sns.heatmap(subset.corr(), annot=True, cmap="coolwarm")

subset = df[["utilization_hrs", "idle_hrs"]]
sns.heatmap(subset.corr(), annot=True, cmap="coolwarm")
    
plt.figure(figsize=(10,8))
sns.heatmap(df.corr(numeric_only=True), annot=True, cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.show()

###### 3. MULTI VARIATE PLOTS..........................................
#####  PAIR PLOTS...............
numeric_cols = df.select_dtypes(include='number').columns

# Pairplot for multivariate analysis
sns.set(style="ticks", palette="Set2")  # Nice style and color palette
pairplot = sns.pairplot(
    df[numeric_cols],
    diag_kind='kde',      # Kernel density estimate on diagonal
    kind='scatter',       # Scatter plots for off-diagonal
    corner=False,         # Show full matrix (not just lower triangle)
    plot_kws={'alpha':0.6, 's':40}  # Transparency and point size
)
pairplot.fig.suptitle("Pairwise Relationships (Multivariate Analysis)", y=1.02)
plt.show()

#### FOR EVERY COLUMN FOR PAIR PLOTS:-
for i, col in enumerate(numeric_cols):
    
    sns.pairplot(df, y_vars=[col], x_vars=numeric_cols.drop(col), height=4, aspect=1, plot_kws={'color': colors[i%len(colors)]})
    plt.suptitle(f'Pair Plot for {col}', y=1.02)
    plt.show()
    

