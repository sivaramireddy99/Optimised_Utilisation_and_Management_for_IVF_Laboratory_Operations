
import pandas as pd  
from sqlalchemy import create_engine 
from urllib.parse import quote
univ = pd.read_csv(r"C:\Users\badam\Downloads\ivf_equipment_utilization_2yrs.csv")
univ

user = 'root'
pw = quote('2933')
db = 'IVF_EQUIPMENTS'

engine = create_engine(f"mysql+pymysql://{user}:{pw}@localhost/{db}")



univ.to_sql('IVF_table', con = engine, if_exists = 'replace', chunksize = 1000, index = False)


sql = 'select * from IVF_table'


univdf = pd.read_sql_query(sql, con = engine)


print(univdf)
